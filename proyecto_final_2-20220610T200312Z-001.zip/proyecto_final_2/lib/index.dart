// Export pages
export 'primero/primero_widget.dart' show PrimeroWidget;
export 'segundo/segundo_widget.dart' show SegundoWidget;
export 'inicio/inicio_widget.dart' show InicioWidget;
export 'usuario/usuario_widget.dart' show UsuarioWidget;
export 'datosempleado/datosempleado_widget.dart' show DatosempleadoWidget;
export 'griedview/griedview_widget.dart' show GriedviewWidget;
export 'clientes/clientes_widget.dart' show ClientesWidget;
export 'listview/listview_widget.dart' show ListviewWidget;
export 'datosdesarrollador/datosdesarrollador_widget.dart'
    show DatosdesarrolladorWidget;
export 'conclusiones/conclusiones_widget.dart' show ConclusionesWidget;
